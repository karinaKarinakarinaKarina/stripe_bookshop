from django.db import models

class Discount(models.Model):
    name = models.CharField(max_length=100, null= True, blank=True, verbose_name='Скидка')
    percents = models.DecimalField(default=0, max_digits=3, decimal_places=0, blank=True, null=True, verbose_name='Скидка в %', unique=True)

    def __str__(self):
        return self.name
    
    class Meta: 
        verbose_name = 'скидку'
        verbose_name_plural = 'Скидки'

class Tax(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name='Название налога')
    percent = models.DecimalField(default=0, max_digits=5, decimal_places=1, blank=False, null=False, verbose_name='Налог в %')

    def __str__(self):
        return self.name
    
    class Meta: 
        verbose_name = 'налог'
        verbose_name_plural = 'Налоги'

class Item(models.Model):
    name = models.CharField(max_length=120, null=False, blank=False, verbose_name='Название')
    description = models.TextField(max_length=1500, null=True, blank=True, verbose_name='Описание')
    price = models.DecimalField(default=0.0, max_digits=10, decimal_places=2, null=False, blank=False, verbose_name='Цена')
    discount = models.ForeignKey(Discount, verbose_name='Скидка', on_delete=models.CASCADE, blank=True, null=True)
    tax = models.ForeignKey(Tax, verbose_name='Налог', on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return self.name
    
    class Meta: 
        verbose_name = 'товар'
        verbose_name_plural = 'Товары'



class Order(models.Model):
    name = models.CharField(max_length=100, unique=True, null=True, blank=True, verbose_name='Номер заказа')
    item = models.ManyToManyField(to=Item, verbose_name="Товары")
    customer_name = models.CharField(max_length=50, verbose_name='Имя заказчика', blank=False, null=False)
    created = models.DateField(verbose_name='Дата создания заказа', blank=False, null=False)

    
    class Meta: 
        verbose_name = 'заказ'
        verbose_name_plural = 'Заказы'
    
        
    def price_total(self):
        total = 0
        for it in self.item.all():
            discount_percent = it.discount.percents if it.discount and hasattr(it.discount, 'percents') else 0
            tax_percent = it.tax.percent if it.tax and hasattr(it.tax, 'percent') else 0

            discounted_price = it.price * (1 - discount_percent // 100)
            final_price = discounted_price * (1 + tax_percent // 100)
            total += final_price
        
        return total

    
    def __str__(self):
        return f"Заказ #{self.name} - {self.created}"

