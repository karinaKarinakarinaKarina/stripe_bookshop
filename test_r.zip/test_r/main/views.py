from django.http import JsonResponse
from django.shortcuts import render
from .models import *

import stripe 

stripe.api_key = 'sk_test_51SVSewF9afYqrnvIDUSexiu5Bc8RfWeAfaY1BzrJLxlkiwiIYb8hCtD3iuxGc2kAZ3Vh084jwi4JosInTLH2aqWW00aszh4zSl'

#возвращает session_id для оплаты выбранного товара
def create_checkout_session(request, id):
    item = Item.objects.get(id=id)
    context={'item':item}
    checkout_session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': item.name,
                        'description': item.description,
                    },
                    'unit_amount': int(item.price * 100),
                },
                'quantity': 1,
        }],
        mode='payment',
        success_url=request.build_absolute_uri('/success/'),
        cancel_url=request.build_absolute_uri('/cancel/'),
        )
    return JsonResponse({'sessionId': checkout_session.id})

def item_detail(request, id): 
    item = Item.objects.get(id=id)
    context = {'item':item}
    return render(request, 'item_details.html', context)

def index_page(request):
    items = Item.objects.all()
    context = {'items': items}
    return render(request, 'index.html', context)

def orders_page(request):
    orders = Order.objects.all()
    context = {'orders' : orders}
    return render(request, 'orders.html', context)


def create_checkout_session_order(request, id):
    order = Order.objects.get(id=id)
    context={'order':order}
    checkout_session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': order.name,
                    },
                    'unit_amount': int(order.price_total() * 100),
                },
                'quantity': 1,
        }],
        mode='payment',
        success_url=request.build_absolute_uri('/success/'),
        cancel_url=request.build_absolute_uri('/cancel/'),
        )
    return JsonResponse({'sessionId': checkout_session.id})
